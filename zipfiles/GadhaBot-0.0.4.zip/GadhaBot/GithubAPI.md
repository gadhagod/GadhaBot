<h1>Github API</h1>
<strong>Create a token</strong><br>
!report lets users write issues that will appear on GitHub. To create GitHub issues with python, we use the GitHub API. Start by creating a personal access token <a href="https://github.com/settings/tokens/new">here</a> with permssions to view public repositories.

<br><div align="center">
<img src="images/GitHubAPITokenScopes.png" style="vertical-align:middle"/>
</div><br>

Copy your token. You will need it to create issues through python.<p>If you wish, you can create another GitHub account for creating isuess as I did. <a href="https://github.com/Discord-User">Here</a> is my bot account for creating issues.</p>
