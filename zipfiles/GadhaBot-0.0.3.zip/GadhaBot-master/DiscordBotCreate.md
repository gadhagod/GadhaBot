<h2>Creating the Bot</h2>
<p>First, you have to create your bot. To do this, go to the <a href="https://discord.com/developers/applications">Discord Developer Portal</a>.<br>
<div align="center">
<img src="README images/CreateApplication.png" style="vertical-align:middle"/>
</div> <p> Go to the <kbd>bot</kbd> tab and click <kbd>Add Bot</kbd>.</p>
<div align="center"><img src="README images/AddBot.png" style="vertical-align:middle"/></div>
<p>Name your bot and chose an icon. To copy your bot token, click <kbd>copy</kbd>. You will need your bot token to control your bot.
<div align="center">
<img src="README images/BotToken.png" style="vertical-align:middle"/>
</div>
